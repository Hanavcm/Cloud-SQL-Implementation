/*eslint-env node, express*/
//------------------------------------------------------------------------------
// 
//------------------------------------------------------------------------------

var express = require("express");
var routes = require("./routes");
var http = require("http");
var path = require("path");
var ibmdb = require("ibm_db");



var app = express();

// All environments
app.set("port", process.env.PORT || 3000);
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "jade");
app.use(express.favicon());
app.use(express.logger("dev"));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(express.cookieParser("your secret here"));
app.use(express.session());
app.use(app.router);
app.use(express.static(path.join(__dirname, "public")));
var db2;
var hasConnect = false;

// Development Environment
if ("development" == app.get("env")) {
  app.use(express.errorHandler());
}

//VCAP_SERVICES used to connect to database named db2.
if (process.env.VCAP_SERVICES) {
    var env = JSON.parse(process.env.VCAP_SERVICES);
	if (env["dashDB"]) {
        hasConnect = false;
		db2 = env["dashDB"][0].credentials;
	}
	
}

// No prior connection established
// Establish new connection with DashDB
if ( hasConnect == false ) {
   db2 = {
        db: "BLUDB",
        hostname: "dashdb-entry-yp-syd01-01.services.au-syd.bluemix.net",
        port: 50000,
        username: "dash5072",
        password: "1igcCrY30Ogb"
     };
}

// Connection string for parsing to index.js function
var connString = "DRIVER={DB2};DATABASE=" + db2.db + ";UID=" + db2.username + ";PWD=" + db2.password + ";HOSTNAME=" + db2.hostname + ";port=" + db2.port;

app.get("/", routes.listSysTables(ibmdb,connString));

// Server Hosting
http.createServer(app).listen(app.get("port"), function(){
  console.log("Express server listening on port " + app.get("port"));
});