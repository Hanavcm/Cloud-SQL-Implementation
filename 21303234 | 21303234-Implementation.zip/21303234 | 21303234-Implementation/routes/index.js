/*eslint-env browser, node*/

//------------------------------------------------------------------------------
// Index 
// Links up to the DashDB using the connection string specified in app.js
// Queries the connected database
// Renders the result using jade
//------------------------------------------------------------------------------
exports.listSysTables = function(ibmdb,connString) {
    return function(req, res) {
    	
       ibmdb.open(connString, function(err, conn) {
			if (err ) {
			 res.send("error occurred " + err.message);
			}
			else {
				
				//Query db
				conn.query("SELECT * from SAMPLEDATA", function(err, tables, moreResultSets) {
				
				//Render output
				if ( !err ) { 
					res.render("tablelist", {
						"tablelist" : tables,
						"tableName" : "Output of Orders",
						"message": "An updated output table of all orders"
					 });

				//Error handling
				} else {
				   res.send("error occurred " + err.message);
				}

				
				//Close the connection to the database
				//param 1: The callback function to execute on completion of close function.	
				conn.close(function(){
					console.log("Connection Closed");
					});
				});
			}
		} );
	   
	};
	};